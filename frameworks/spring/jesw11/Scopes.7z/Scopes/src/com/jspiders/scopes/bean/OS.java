package com.jspiders.scopes.bean;

public class OS {
	
	public OS() {
		System.out.println("os created");
	}

}
